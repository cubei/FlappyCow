/** Automatically generated file. DO NOT MODIFY */
package com.google.example.games.basegameutils;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}